#ifndef __SOCKET_H
#define __SOCKET_H

#include <winsock2.h>
#include <sys/ws2tcpip.h>

#endif