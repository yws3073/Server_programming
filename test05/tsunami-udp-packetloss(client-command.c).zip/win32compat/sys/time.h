#ifndef __TIME_H
#define __TIME_H

typedef	long	time_t;

#endif